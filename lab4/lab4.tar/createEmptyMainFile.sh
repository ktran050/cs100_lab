#!/bin/sh
touch main.cc
cat kevin_861172609.txt >> main.cc
echo "int main( int argc, const char** argv)
	{}" >> main.cc
